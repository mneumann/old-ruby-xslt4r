#!/usr/bin/ruby

class Array
  def sum
    sum = 0
    each { |i| sum += i }
    sum
  end
end


entries = gets.chomp.split("\t")
columns = gets.chomp.split("\t")

@sizes = []
@lines = []
records = columns.collect { entries.collect { [] } }

record_col = []
entries.size.times { |n| records.each { |a| record_col.push a[n] } }

while gets
  file, size, line, *record = split("\t")
  unless record.size == record_col.size then
    STDERR.print "parse error\n"
    break
  end
  @sizes.push size.to_i
  @lines.push line.to_i
  record.each_with_index { |i,n|
    if /\A\d/ =~ i then
      record_col[n].push i.to_f
    else
      record_col[n].push nil
    end
  }
end


print <<_
                               total   total   bytes   lines     total   msec
   scanner           files      size   lines     /file   /file  seconds   /file
_
#------------------- ----- --------- ------- -------.- -----.- -----.-- ----.--

total_size = @sizes.sum
total_lines = @lines.sum
printf(" %-25s        --      -- %7d   %5d         --      --\n",
       '-- (min)', @sizes.min, @lines.min)
printf(" %-19s %5d %9d %7d %9.1f %7.1f %8s %7s\n",
       '--', @sizes.size, total_size, total_lines,
       total_size.to_f / @sizes.size,
       total_lines.to_f / @sizes.size, '--', '--')
printf(" %-25s        --      -- %7d   %5d         --      --\n\n",
       '-- (max)', @sizes.max, @lines.max)

def summarize(scanner, record, others = [])
  files = 0
  total_size = total_lines = total_seconds = 0
  max_size = max_lines = max_seconds = 0
  min_size = min_lines = min_seconds = nil
  record.each_with_index { |sec,n|
    next if sec.nil? or others.find { |a| a[n].nil? }
    files += 1
    size, line = @sizes[n], @lines[n]
    total_size += size
    total_lines += line
    total_seconds += sec
    max_size    = size if max_size    < size
    max_lines   = line if max_lines   < line
    max_seconds = sec  if max_seconds < sec
    min_size    = size unless min_size    and min_size    <= size
    min_lines   = line unless min_lines   and min_lines   <= line
    min_seconds = sec  unless min_seconds and min_seconds <= sec
  }
  printf(" %-25s        --      -- %7d   %5d         -- %7.2f\n",
         scanner + ' (min)', min_size.to_i, min_lines.to_i,
         (min_seconds or 0) * 1000.0)
  printf(" %-19s %5d %9d %7d %9.1f %7.1f %8.2f %7.2f\n",
         scanner, files,
         total_size, total_lines, total_size.to_f / files,
         total_lines.to_f / files,
         total_seconds, total_seconds * 1000.0 / files)
  printf(" %-25s        --      -- %7d   %5d         -- %7.2f\n\n",
         scanner + ' (max)', max_size, max_lines, max_seconds * 1000.0)
end

columns.each_with_index { |col,cn|
  print col, ":\n\n"
  entries.each_with_index { |i,n| summarize i, records[cn][n] }
  print col, " (commonly succeeded):\n\n"
  entries.each_with_index { |i,n| summarize i, records[cn][n], records[cn] }
}
