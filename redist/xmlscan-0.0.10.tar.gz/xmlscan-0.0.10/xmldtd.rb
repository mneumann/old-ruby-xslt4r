if not File.exist?('xmldtd.tab.rb') or
    File.mtime('xmldtd.ry') > File.mtime('xmldtd.tab.rb') then
  STDERR.print "racc xmldtd.ry ...\n"
  system "racc -v -g -c xmldtd.ry"
  exit $? if $? != 0
  STDERR.print "racc done.\n"
end
load 'xmldtd.tab.rb'
